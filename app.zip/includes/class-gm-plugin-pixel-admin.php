<?php

class Ghostmonitor_Pixel_Admin {
	public function __construct() {
		add_menu_page( 'WooCommerce Facebook Pixel', 'WooCommerce Facebook Pixel', 'manage_options', 'woocommerce-facebook-pixel', array( $this, 'add_admin_page' ) );
	}

	public function add_admin_page() {
		include_once( GHOSTMONITOR_PIXEL_PATH . 'admin/gm-plugin-pixel-admin-menu.php' );
	}
}