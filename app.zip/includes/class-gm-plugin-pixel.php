<?php

class Ghostmonitor_Pixel {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'init' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'load_admin_scripts' ) );
		add_action( 'wp_ajax_gm_plugin_pixel_save', array( $this, 'gm_plugin_pixel_save' ) );
		add_action( 'wp_ajax_gm_plugin_pixel_delete', array( $this, 'gm_plugin_pixel_delete' ) );
		add_action( 'wp_footer', array($this, 'load_public_script') );
		add_action( 'woocommerce_thankyou', array($this, 'load_public_script') );
	}

	public function init() {
		include_once(GHOSTMONITOR_PIXEL_PATH . 'includes/class-gm-plugin-pixel-admin.php');
		new Ghostmonitor_Pixel_Admin();
	}

	public function load_public_script( $order_id = false ) {
		if( ! get_option( 'gm_pixel_enabled' ) ) {
			return;
		}
		$page_settings = get_option( 'gm_pixel_page_settings' );
		$woo_settings  = get_option( 'gm_pixel_woocommerce_settings' );
		$pixel_id      = get_option( 'gm_pixel_id' );

		if ( !$page_settings && !$pixel_id && !$woo_settings) {
			return;
		}

		$page_settings = maybe_unserialize( $page_settings );
		$woo_settings  = maybe_unserialize( $woo_settings );

		include_once( GHOSTMONITOR_PIXEL_PATH . 'includes/class-gm-plugin-pixel-public.php' );
		$gm_pixel_public = new Ghostmonitor_Pixel_Public();

		if ( function_exists('is_woocommerce') && function_exists('is_checkout') && function_exists('is_cart') && !empty($woo_settings) ) {
			if(is_product() && (bool)$woo_settings['addtocart']) {
				echo $gm_pixel_public->load_script( $pixel_id, 'ViewContent' );
				return;
			}
			elseif( $order_id != false && (bool)$woo_settings['thankyou'] ) {
				if(!(bool)$woo_settings['thankyou']) {
					return;
				}
				$order = new WC_Order_Factory();
				$order = $order->get_order($order_id);
				$value = $order->calculate_totals();
				$currency = $order->get_order_currency();
				echo $gm_pixel_public->load_script( $pixel_id, 'Purchase', array('value' => $value, 'currency' => $currency) );
				return;
			}
			elseif(is_checkout() && (bool)$woo_settings['checkout'] && strpos( $_SERVER['REQUEST_URI'], 'order-received' ) === false ) {
				echo $gm_pixel_public->load_script( $pixel_id, 'InitiateCheckout' );
				return;
			}
			elseif(is_woocommerce() && (bool)$woo_settings['anypage']) {
				echo $gm_pixel_public->load_script( $pixel_id, 'ViewContent' );
				return;
			}
		}

		$page_settings = array_filter($page_settings, function($elem) {
			$request_uri = $_SERVER['REQUEST_URI'];
			$parsed_url = parse_url($elem['url']);
			return trailingslashit($parsed_url['path']) === $request_uri;
		});

		if( empty($page_settings) ) {
			return;
		}

		$page_settings = array_shift($page_settings);

		echo $gm_pixel_public->load_script( $pixel_id, $page_settings['event'] );
	}

	public function load_admin_scripts($hook) {
		if ( 'toplevel_page_woocommerce-facebook-pixel' != $hook ) {
			return;
		}

		wp_register_script( 'gm_plugin_pixel_save',   GHOSTMONITOR_PIXEL_URL . 'admin/js/gm-plugin-pixel-admin-save.js',   array('jquery'), false, true );
		wp_register_script( 'gm_plugin_pixel_delete', GHOSTMONITOR_PIXEL_URL . 'admin/js/gm-plugin-pixel-admin-delete.js', array('jquery'), false, true );
		wp_register_script( 'gm_plugin_pixel_new',    GHOSTMONITOR_PIXEL_URL . 'admin/js/gm-plugin-pixel-admin-new.js',    array('jquery'), false, true );

		wp_localize_script(
			'gm_plugin_pixel_save', 
			'gmPluginPixelSaveNonce', 
			array(
				'nonce' => wp_create_nonce( 'gm_plugin_pixel_save_nonce' ),
			)
		);

		wp_enqueue_script( 'gm_plugin_pixel_save' );
		wp_enqueue_script( 'gm_plugin_pixel_delete' );
		wp_enqueue_script( 'gm_plugin_pixel_new' );
	}

	public function gm_plugin_pixel_save() {
		check_ajax_referer( 'gm_plugin_pixel_save_nonce', 'nonce', true );

		foreach( $_POST as $key => $val) {
			if( $key === 'gm_pixel_id' && ( ! empty( $val ) ) ) {
				update_option($key, trim($val), true);
			}
			if( $key === 'gm_pixel_enabled' && ( (int)$key === 0 || (int)$key === 1 ) ) {
				update_option($key, trim($val), true);
			}
			if( $key === 'gm_pixel_page_settings' && ( ! empty( $val ) ) ) {
				$page_settings = json_decode(stripslashes(html_entity_decode(trim($val))), true);
				update_option('gm_pixel_page_settings', maybe_serialize($page_settings), true);
			}
			if( $key === 'gm_pixel_woocommerce_settings'  && ( ! empty( $val ) ) ) {
				$woocommerce_settings = json_decode(stripslashes(html_entity_decode(trim($val))), true);
				update_option('gm_pixel_woocommerce_settings', maybe_serialize($woocommerce_settings), true);
			}
		}

		echo 'Settings Saved!';

		wp_die();
	}

	public function gm_plugin_pixel_delete() {
		check_ajax_referer( 'gm_plugin_pixel_save_nonce', 'nonce', true );

		$page_settings = maybe_unserialize( get_option( 'gm_pixel_page_settings' ) );

		if( !isset($_POST['gm_pixel_page_url']) || !isset($_POST['gm_pixel_page_event']) ) {
			wp_die('Error: no `url` or `event` parameter!');
		}

		foreach( $page_settings as $key => $ps ) {
			if ( $ps['url'] ==  $_POST['gm_pixel_page_url'] && $ps['event'] == $_POST['gm_pixel_page_event'] ) {
				unset($page_settings[$key]);
				break;
			}
		}

		$page_settings = array_values($page_settings);

		update_option('gm_pixel_page_settings', maybe_serialize($page_settings), true);

		echo 'Page deleted!';

		wp_die();
	}
}
